# 2021-s-toyproject-MegaCoffee
3학년1학기 여름방학 웹 공부하기 위한 간단한 프로젝트

https://123rudgks.github.io/2021-s-toyproject-MegaCoffee/MegaCoffee/index.html

### 수정해야 할 오류 ###
1. BrandStory에서 context-2 의 내용들 가운데 정렬하기
2. BrandStory에서 전체 div의 아래쪽 길이 늘려주기 (현재 context-2와 너무 붙어있음)
